package.preload[ "Health_Bars.bar_customization" ] = assert( (loadstring or load)( "local this = {};\
\
local utils;\
local config;\
local screen;\
local customization_menu;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
local outline_styles = {\"Inside\", \"Center\", \"Outside\"};\
\
function this.draw(bar_name, bar)\
\9if bar == nil then\
\9\9return false;\
\9end\
\
\9if bar_name == nil then\
\9\9bar_name = \"\";\
\9end\
\
\9local bar_changed = false;\
\9local changed = false;\
\9local index = 1;\
\
\9if imgui.tree_node(bar_name) then\
\9\9changed, bar.visibility = imgui.checkbox(\"Visible\" , bar.visibility);\
\9\9bar_changed = bar_changed or changed;\
\
\9\9if imgui.tree_node(\"Offset\") then\
\9\9\9changed, bar.offset.x = imgui.drag_float(\"X\",\
\9\9\9\9bar.offset.x, 0.1, -screen.width, screen.width, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9changed, bar.offset.y = imgui.drag_float(\"Y\",\
\9\9\9\9bar.offset.y, 0.1, -screen.height, screen.height, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9imgui.tree_pop();\
\9\9end\
\
\9\9if imgui.tree_node(\"Size\") then\
\9\9\9changed, bar.size.width = imgui.drag_float(\"Width\",\
\9\9\9\9bar.size.width, 0.1, 0, screen.width, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9changed, bar.size.height = imgui.drag_float(\"Height\",\
\9\9\9\9bar.size.height, 0.1, 0, screen.height, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9imgui.tree_pop();\
\9\9end\
\
\9\9if imgui.tree_node(\"Outline\") then\
\9\9\9changed, bar.outline.visibility = imgui.checkbox(\"Visible\"\
\9\9\9\9, bar.outline.visibility);\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9changed, bar.outline.thickness = imgui.drag_float(\"Thickness\",\
\9\9\9\9bar.outline.thickness, 0.1, 0, screen.width, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9changed, bar.outline.offset = imgui.drag_float(\"Offset\",\
\9\9\9\9bar.outline.offset, 0.1, -screen.height, screen.height, \"%.1f\");\
\9\9\9bar_changed = bar_changed or changed;\
\
\
\9\9\9changed, index = imgui.combo(\"Style\",\
\9\9\9\9utils.table_find_index(outline_styles, bar.outline.style),\
\9\9\9\9outline_styles);\
\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9if changed then\
\9\9\9\9bar.outline.style = outline_styles[index];\
\9\9\9end\
\
\9\9\9imgui.tree_pop();\
\9\9end\
\
\9\9if imgui.tree_node(\"Colors\") then\
\9\9\9if imgui.tree_node(\"Foreground\") then\
\9\9\9\9changed, bar.colors.foreground = imgui.color_picker_argb(\"\", bar.colors.foreground,\
\9\9\9\9\9customization_menu.color_picker_flags);\
\9\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9\9imgui.tree_pop();\
\9\9\9end\
\
\9\9\9if imgui.tree_node(\"Background\") then\
\9\9\9\9changed, bar.colors.background = imgui.color_picker_argb(\"\", bar.colors.background,\
\9\9\9\9\9customization_menu.color_picker_flags);\
\9\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9\9imgui.tree_pop();\
\9\9\9end\
\
\9\9\9if imgui.tree_node(\"Outline\") then\
\9\9\9\9changed, bar.colors.outline = imgui.color_picker_argb(\"\", bar.colors.outline,\
\9\9\9\9\9customization_menu.color_picker_flags);\
\9\9\9\9bar_changed = bar_changed or changed;\
\
\9\9\9\9imgui.tree_pop();\
\9\9\9end\
\
\9\9\9imgui.tree_pop();\
\9\9end\
\
\9\9bar_changed = bar_changed or changed;\
\
\9\9imgui.tree_pop();\
\9end\
\
\9return bar_changed;\
end\
\
function this.init_module()\
\9utils = require(\"Health_Bars.utils\");\
\9config = require(\"Health_Bars.config\");\
\9screen = require(\"Health_Bars.screen\");\
\9customization_menu = require(\"Health_Bars.customization_menu\");\
end\
\
return this;\
", '@'..".\\Health_Bars\\bar_customization.lua" ) )

package.preload[ "Health_Bars.config" ] = assert( (loadstring or load)( "local this = {};\
\
local utils;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
this.current_config = nil;\
this.config_file_name = \"Health Bars/config.json\";\
\
this.default_config = {};\
\
function this.init()\
\9this.default_config = {\
\9\9enabled = true,\
\
\9\9settings = {\
\9\9\9use_d2d_if_available = true,\
\9\9\9hide_if_dead = true,\
\9\9\9hide_if_no_ray_to_player = true,\
\9\9\9opacity_falloff = true,\
\9\9\9max_distance = 30\
\9\9},\
\
\9\9world_offset = {\
\9\9\9x = 0,\
\9\9\9y = 1.85,\
\9\9\9z = 0\
\9\9},\
\
\9\9health_bar = {\
\9\9\9visibility = true,\
\
\9\9\9offset = {\
\9\9\9\9x = -75,\
\9\9\9\9y = 0\
\9\9\9},\
\
\9\9\9size = {\
\9\9\9\9width = 150,\
\9\9\9\9height = 8\
\9\9\9},\
\
\9\9\9outline = {\
\9\9\9\9visibility = true,\
\9\9\9\9thickness = 2,\
\9\9\9\9offset = 0,\
\9\9\9\9style = \"Center\"\
\9\9\9},\
\
\9\9\9colors = {\
\9\9\9\9foreground = 0xB974A652,\
\9\9\9\9background = 0xB9000000,\
\9\9\9\9outline = 0xC0000000\
\9\9\9}\
\9\9}\
\9};\
end\
\
function this.load()\
\9local loaded_config = json.load_file(this.config_file_name);\
\9if loaded_config ~= nil then\
\9\9log.info(\"[Health Bars] config.json loaded successfully\");\
\9\9this.current_config = utils.table_merge(this.default_config, loaded_config);\
\9else\
\9\9log.error(\"[Health Bars] Failed to load config.json\");\
\9\9this.current_config = utils.table_deep_copy(this.default_config);\
\9end\
end\
\
function this.save()\
\9-- save current config to disk, replacing any existing file\
\9local success = json.dump_file(this.config_file_name, this.current_config);\
\9if success then\
\9\9log.info(\"[Health Bars] config.json saved successfully\");\
\9else\
\9\9log.error(\"[Health Bars] Failed to save config.json\");\
\9end\
end\
\
function this.init_module()\
\9utils = require(\"Health_Bars.utils\");\
\
\9this.init();\
\9this.load();\
\9this.current_config.version = \"1.0\";\
end\
\
return this;\
", '@'..".\\Health_Bars\\config.lua" ) )

package.preload[ "Health_Bars.customization_menu" ] = assert( (loadstring or load)( "local this = {};\
\
local utils;\
local config;\
local bar_customization;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
this.status = \"OK\";\
\
this.font = nil;\
this.font_range = {0x1, 0xFFFF, 0};\
this.is_opened = false;\
\
this.window_position = Vector2f.new(480, 200);\
this.window_pivot = Vector2f.new(0, 0);\
this.window_size = Vector2f.new(450, 450);\
this.window_flags = 0x10120;\
this.color_picker_flags = 327680;\
this.decimal_input_flags = 33;\
\
this.config_changed = false;;\
\
function this.init()\
end\
\
function this.draw()\
\9local cached_config = config.current_config;\
\
\9imgui.set_next_window_pos(this.window_position, 1 << 3, this.window_pivot);\
\9imgui.set_next_window_size(this.window_size, 1 << 3);\
\
\9this.is_opened = imgui.begin_window(\
\9\9\"Health Bars v\" .. config.current_config.version, this.is_opened, this.window_flags);\
\
\9if not this.is_opened then\
\9\9imgui.end_window();\
\9\9return;\
\9end\
\
\9imgui.text(\"Status: \" .. tostring(this.status));\
\
\9local changed = false;\
\9local config_changed = false;\
\
\9local index = 1;\
\
\9changed, cached_config.enabled = imgui.checkbox(\"Enabled\", cached_config.enabled);\
\9config_changed = config_changed or changed;\
\
\9if imgui.tree_node(\"Settings\") then\
\9\9changed, cached_config.settings.use_d2d_if_available = imgui.checkbox(\"Use Direct2D Renderer if Available\",\
\9\9\9cached_config.settings.use_d2d_if_available);\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.settings.hide_if_dead = imgui.checkbox(\"Hide if Dead\",\
\9\9\9cached_config.settings.hide_if_dead);\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.settings.hide_if_no_ray_to_player = imgui.checkbox(\"Hide if No Ray to Player\",\
\9\9\9cached_config.settings.hide_if_no_ray_to_player);\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.settings.opacity_falloff = imgui.checkbox(\"Opacity Falloff\",\
\9\9\9cached_config.settings.opacity_falloff);\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.settings.max_distance = imgui.drag_float(\"Max Distance\",\
\9\9\9cached_config.settings.max_distance, 1, 0, 10000, \"%.0f\");\
\9\9config_changed = config_changed or changed;\
\
\9\9imgui.tree_pop();\
\9end\
\
\9if imgui.tree_node(\"World Offset\") then\
\9\9changed, cached_config.world_offset.x = imgui.drag_float(\"X\",\
\9\9\9cached_config.world_offset.x, 0.01, -10, 10, \"%.2f\");\
\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.world_offset.y = imgui.drag_float(\"Y\",\
\9\9\9cached_config.world_offset.y, 0.01, -10, 10, \"%.2f\");\
\
\9\9config_changed = config_changed or changed;\
\
\9\9changed, cached_config.world_offset.z = imgui.drag_float(\"Z\",\
\9\9\9\9cached_config.world_offset.z, 0.01, -10, 10, \"%.2f\");\
\
\9\9config_changed = config_changed or changed;\
\
\9\9imgui.tree_pop();\
\9end\
\
\9changed = bar_customization.draw(\"Health Bar\", cached_config.health_bar);\
\9config_changed = config_changed or changed;\
\9\
\9imgui.end_window();\
\
\9if config_changed then\
\9\9config.save();\
\9end\
end\
\
function this.init_module()\
\9utils = require(\"Health_Bars.utils\");\
\9config = require(\"Health_Bars.config\");\
\9bar_customization = require(\"Health_Bars.bar_customization\");\
\
\9this.init();\
end\
\
return this;", '@'..".\\Health_Bars\\customization_menu.lua" ) )

package.preload[ "Health_Bars.drawing" ] = assert( (loadstring or load)( "local this = {};\
\
local config;\
local utils;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
this.font = nil;\
\
function this.init_font()\
\9this.font = d2d.Font.new(\"Consolas\", 13, true, false);\
end\
\
function this.argb_color_to_abgr_color(argb_color)\
\9local alpha = (argb_color >> 24) & 0xFF;\
\9local red = (argb_color >> 16) & 0xFF;\
\9local green = (argb_color >> 8) & 0xFF;\
\9local blue = argb_color & 0xFF;\
\
\9local abgr_color = 0x1000000 * alpha + 0x10000 * blue + 0x100 * green + red;\
\
\9return abgr_color;\
end\
\
function this.color_to_argb(color)\
\9local alpha = (color >> 24) & 0xFF;\
\9local red = (color >> 16) & 0xFF;\
\9local green = (color >> 8) & 0xFF;\
\9local blue = color & 0xFF;\
\
\9return alpha, red, green, blue;\
end\
\
function this.argb_to_color(alpha, red, green, blue)\
\9return 0x1000000 * alpha + 0x10000 * red + 0x100 * green + blue;\
end\
\
function this.scale_color_opacity(color, scale)\
\9local alpha, red, green, blue = this.color_to_argb(color);\
\9local new_alpha = math.floor(alpha * scale);\
\9if new_alpha < 0 then\
\9\9new_alpha = 0;\
\9end\
\9if new_alpha > 255 then\
\9\9new_alpha = 255;\
\9end\
\
\9return this.argb_to_color(new_alpha, red, green, blue);\
end\
\
function this.scale_bar_opacity(bar, scale)\
\9if bar == nil or scale == nil or not bar.visibility then\
\9\9return;\
\9end\
\
\9bar.colors.foreground = this.scale_color_opacity(bar.colors.foreground, scale);\
\9bar.colors.background = this.scale_color_opacity(bar.colors.background, scale);\
end\
\
function this.scale_label_opacity(label, scale)\
\9if label == nil or scale == nil or not label.visibility then\
\9\9return;\
\9end\
\
\9label.color = this.scale_color_opacity(label.color, scale);\
\9label.shadow.color = this.scale_color_opacity(label.shadow.color, scale);\
end\
\
function this.draw_bar(bar, position, opacity_scale, percentage)\
\9if bar == nil or not bar.visibility then\
\9\9return;\
\9end\
\
\9if percentage > 1 then\
\9\9percentage = 1;\
\9end\
\
\9if percentage < 0 then\
\9\9percentage = 0;\
\9end\
\
\9local outline_visibility = bar.outline.visibility;\
\9local style = bar.outline.style; -- Inside/Center/Outside\
\
\9local outline_thickness = bar.outline.thickness;\
\9if not outline_visibility then\
\9\9outline_thickness = 0;\
\9end\
\
\9local half_outline_thickness = outline_thickness / 2;\
\
\9local outline_offset = bar.outline.offset;\
\
\9if outline_thickness == 0 then\
\9\9outline_offset = 0;\
\9end\
\9local half_outline_offset = outline_offset / 2;\
\
\9local outline_position_x = 0;\
\9local outline_position_y = 0;\
\
\9local outline_width = 0;\
\9local outline_height = 0;\
\
\9local position_x = 0;\
\9local position_y = 0;\
\
\9local foreground_width = 0;\
\9local background_width = 0;\
\9local height = 0;\
\
\9if style == \"Inside\" then\
\9\9outline_position_x = position.x + bar.offset.x + half_outline_thickness;\
\9\9outline_position_y = position.y + bar.offset.y + half_outline_thickness;\
\
\9\9outline_width = bar.size.width - outline_thickness;\
\9\9outline_height = bar.size.height - outline_thickness;\
\
\9\9position_x = outline_position_x + half_outline_thickness + outline_offset;\
\9\9position_y = outline_position_y + half_outline_thickness + outline_offset;\
\
\9\9local width = outline_width - outline_thickness - outline_offset - outline_offset;\
\9\9foreground_width = width * percentage;\
\9\9background_width = width - foreground_width;\
\
\9\9height = outline_height - outline_thickness - outline_offset - outline_offset;\
\
\9elseif style == \"Center\" then\
\9\9outline_position_x = position.x + bar.offset.x - half_outline_offset;\
\9\9outline_position_y = position.y + bar.offset.y - half_outline_offset;\
\
\9\9outline_width = bar.size.width + outline_offset;\
\9\9outline_height = bar.size.height + outline_offset;\
\
\9\9position_x = outline_position_x + half_outline_thickness + outline_offset;\
\9\9position_y = outline_position_y + half_outline_thickness + outline_offset;\
\
\9\9local width = outline_width - outline_thickness - outline_offset - outline_offset;\
\9\9foreground_width = width * percentage;\
\9\9background_width = width - foreground_width;\
\
\9\9height = outline_height - outline_thickness - outline_offset - outline_offset;\
\
\9else\
\9\9position_x = position.x + bar.offset.x;\
\9\9position_y = position.y + bar.offset.y;\
\
\9\9local width = bar.size.width;\
\9\9height = bar.size.height;\
\
\9\9foreground_width = width * percentage;\
\9\9background_width = width - foreground_width;\
\
\9\9outline_position_x = position_x - half_outline_thickness - outline_offset;\
\9\9outline_position_y = position_y - half_outline_thickness - outline_offset;\
\
\9\9outline_width = width + outline_thickness + outline_offset + outline_offset;\
\9\9outline_height = height + outline_thickness + outline_offset + outline_offset;\
\9end\
\
\9local foreground_color = bar.colors.foreground;\
\9local background_color = bar.colors.background;\
\9local outline_color = bar.colors.outline;\
\
\9if opacity_scale < 1 then\
\9\9foreground_color = this.scale_color_opacity(foreground_color, opacity_scale);\
\9\9background_color = this.scale_color_opacity(background_color, opacity_scale);\
\9\9outline_color = this.scale_color_opacity(outline_color, opacity_scale);\
\9end\
\
\9local use_d2d = d2d ~= nil and config.current_config.settings.use_d2d_if_available;\
\
\9-- outline\
\9if outline_thickness ~= 0 then\
\9\9if use_d2d then\
\9\9\9d2d.outline_rect(outline_position_x, outline_position_y, outline_width, outline_height, outline_thickness, outline_color);\
\9\9else\
\9\9\9outline_color = this.argb_color_to_abgr_color(outline_color);\
\9\9\9draw.outline_rect(outline_position_x, outline_position_y, outline_width, outline_height, outline_color);\
\9\9end\
\9end\
\
\9-- foreground\
\9if foreground_width ~= 0 then\
\9\9if use_d2d then\
\9\9\9d2d.fill_rect(position_x, position_y, foreground_width, height, foreground_color);\
\9\9else\
\9\9\9foreground_color = this.argb_color_to_abgr_color(foreground_color);\
\9\9\9draw.filled_rect(position_x, position_y, foreground_width, height, foreground_color)\
\9\9end\
\9end\
\
\9-- background\
\9if background_width ~= 0 then\
\9\9if use_d2d then\
\9\9\9d2d.fill_rect(position_x + foreground_width, position_y, background_width, height, background_color);\
\9\9else\
\9\9\9background_color = this.argb_color_to_abgr_color(background_color);\
\9\9\9draw.filled_rect(position_x + foreground_width, position_y, background_width, height, background_color)\
\9\9end\
\9end\
end\
\
function this.init_module()\
\9config = require(\"Health_Bars.config\");\
\9utils = require(\"Health_Bars.utils\");\
end\
\
return this;\
", '@'..".\\Health_Bars\\drawing.lua" ) )

package.preload[ "Health_Bars.enemy_handler" ] = assert( (loadstring or load)( "local this = {};\
\
local utils;\
local singletons;\
local config;\
local drawing;\
local customization_menu;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
this.enemy_list = {};\
this.player_position = Vector3f.new(0, 0, 0);\
\
local character_manager_type_def = sdk.find_type_definition(\"chainsaw.CharacterManager\");\
local get_enemy_context_list_method = character_manager_type_def:get_method(\"get_EnemyContextList\");\
local get_player_context_method = character_manager_type_def:get_method(\"getPlayerContextRef\");\
\
local enemy_context_list_type_def = get_enemy_context_list_method:get_return_type();\
local enemy_context_list_get_count_method = enemy_context_list_type_def:get_method(\"get_Count\");\
local enemy_context_list_get_item_method = enemy_context_list_type_def:get_method(\"get_Item\");\
\
local enemy_base_context_type_def = sdk.find_type_definition(\"chainsaw.EnemyBaseContext\");\
local get_position_method = enemy_base_context_type_def:get_method(\"get_Position\");\
local get_has_ray_to_player_method = enemy_base_context_type_def:get_method(\"get_HasRayToPlayer\");\
local get_hit_point_method = enemy_base_context_type_def:get_method(\"get_HitPoint\");\
\
local hit_point_type_def = get_hit_point_method:get_return_type();\
local get_default_hit_point_method = hit_point_type_def:get_method(\"get_DefaultHitPoint\");\
local get_current_hit_point_method = hit_point_type_def:get_method(\"get_CurrentHitPoint\");\
local get_is_live_method = hit_point_type_def:get_method(\"get_IsLive\");\
\
local player_base_context_type_def = sdk.find_type_definition(\"chainsaw.PlayerBaseContext\");\
local get_player_position_method = player_base_context_type_def:get_method(\"get_Position\");\
\
function this.new(enemy_context, health, max_health, is_live, has_ray_to_player, position)\
\9local enemy = {};\
\9enemy.enemy_context = enemy_context;\
\
\9enemy.distance = 0;\
\
\9health = health or 0;\
\9max_health = max_health or 1;\
\9if is_live == nil then is_live = false; end\
\9if has_ray_to_player == nil then has_ray_to_player = false; end\
\9position = position or Vector3f.new(0, 0, 0);\
\
\9this.set_health(enemy, health, max_health, is_live);\
\9this.set_has_ray_to_player(enemy, has_ray_to_player);\
\9this.set_position(enemy, position);\
\
\9this.enemy_list[enemy_context] = enemy;\
\
\9return enemy;\
end\
\
function this.get_enemy(enemy_context)\
\9local enemy = this.enemy_list[enemy_context];\
\9if enemy == nil then\
\9\9enemy = this.new(enemy_context);\
\9end\
\9\
\9return enemy;\
end\
\
function this.set_health(enemy, health, max_health, is_live)\
\9if enemy == nil then\
\9\9return;\
\9end\
\
\9if health == nil then\
\9\9customization_menu.status = \"No Enemy Health\";\
\9\9return;\
\9end\
\
\9enemy.health = health;\
\
\9if max_health == nil then\
\9\9customization_menu.status = \"No Enemy MaxHealth\";\
\9\9return;\
\9end\
\
\9enemy.max_health = max_health;\
\
\9if max_health == 0 then\
\9\9enemy.health_percentage = 0;\
\9else\
\9\9enemy.health_percentage = health / max_health;\
\9end\
\
\9if is_live == nil then\
\9\9customization_menu.status = \"No Enemy IsLive\";\
\9\9return;\
\9end\
\
\9enemy.is_live = is_live;\
end\
\
function this.set_has_ray_to_player(enemy, has_ray_to_player)\
\9if enemy == nil then\
\9\9return;\
\9end\
\
\9if has_ray_to_player == nil then\
\9\9customization_menu.status = \"No Enemy HasRayToPlayer\";\
\9\9return;\
\9end\
\
\9enemy.has_ray_to_player = has_ray_to_player;\
end\
\
function this.set_position(enemy, position)\
\9if enemy == nil then\
\9\9return;\
\9end\
\
\9if position == nil then\
\9\9customization_menu.status = \"No Enemy Position\";\
\9\9return;\
\9end\
\
\9enemy.position = position;\
\
\9if this.player_position == nil then\
\9\9return;\
\9end\
\
\9enemy.distance = (this.player_position - position):length();\
end\
\
function this.update_enemies()\
\9if singletons.character_manager == nil then\
\9\9customization_menu.status = \"No Character Manager\";\
\9\9return;\
\9end\
\
\9local enemy_context_list = get_enemy_context_list_method:call(singletons.character_manager);\
\9if enemy_context_list == nil then\
\9\9customization_menu.status = \"No Enemy Context List\";\
\9\9return;\
\9end\
\
\9local count = enemy_context_list_get_count_method:call(enemy_context_list);\
\9if count == nil then\
\9\9customization_menu.status = \"No Enemy Context List Count\";\
\9\9return;\
\9end\
\
\9this.enemy_list = {};\
\
\9for i = 0, count - 1 do\
\9\9local enemy_context = enemy_context_list_get_item_method:call(enemy_context_list, i);\
\9\9if enemy_context == nil then\
\9\9\9customization_menu.status = \"No Enemy Context\";\
\9\9\9goto continue;\
\9\9end\
\
\9\9local enemy = this.get_enemy(enemy_context);\
\
\9\9local position = get_position_method:call(enemy_context);\
\9\9local has_ray_to_player = get_has_ray_to_player_method:call(enemy_context);\
\
\9\9local default_hit_point;\
\9\9local current_hit_point;\
\9\9local is_live;\
\
\9\9local hit_point = get_hit_point_method:call(enemy_context);\
\
\9\9if hit_point ~= nil then\
\9\9\9default_hit_point = get_default_hit_point_method:call(hit_point);\
\9\9\9current_hit_point = get_current_hit_point_method:call(hit_point);\
\9\9\9is_live = get_is_live_method:call(hit_point);\
\9\9end\
\
\9\9this.set_position(enemy, position);\
\9\9this.set_has_ray_to_player(enemy, has_ray_to_player);\
\9\9this.set_health(enemy, current_hit_point, default_hit_point, is_live);\
\
\9\9::continue::\
\9end\
end\
\
function this.draw_enemies()\
\9local cached_config = config.current_config;\
\
\9for enemy_context, enemy in pairs(this.enemy_list) do\
\9\9if cached_config.settings.max_distance == 0 then\
\9\9\9break;\
\9\9end\
\
\9\9if  cached_config.settings.hide_if_dead and not enemy.is_live then\
\9\9\9goto continue;\
\9\9end\
\
\9\9if cached_config.settings.hide_if_no_ray_to_player and not enemy.has_ray_to_player then\
\9\9\9goto continue;\
\9\9end\
\
\9\9if enemy.distance > cached_config.settings.max_distance then\
\9\9\9goto continue;\
\9\9end\
\
\9\9local world_offset = Vector3f.new(cached_config.world_offset.x, cached_config.world_offset.y, cached_config.world_offset.z);\
\
\9\9local position_on_screen = draw.world_to_screen(enemy.position + world_offset);\
\9\9if position_on_screen == nil then\
\9\9\9goto continue;\
\9\9end\
\
\9\9local opacity_scale = 1;\
\9\9if cached_config.settings.opacity_falloff then\
\9\9\9opacity_scale = 1 - (enemy.distance / cached_config.settings.max_distance);\
\9\9end\
\
\9\9drawing.draw_bar(cached_config.health_bar, position_on_screen, opacity_scale, enemy.health_percentage);\
\9\9::continue::\
\9end\
end\
\
function this.update_player_position()\
    if singletons.character_manager == nil then\
\9\9customization_menu.status = \"No Character Manager\";\
        return;\
    end\
\
\9local player_context = get_player_context_method:call(singletons.character_manager);\
\9if player_context == nil then\
\9\9customization_menu.status = \"No Player Context\";\
\9\9return;\
\9end\
\
\9local position = get_player_position_method:call(player_context);\
\9if position == nil then\
\9\9customization_menu.status = \"No Player Position\";\
\9\9return;\
\9end\
\
   this.player_position = position;\
end\
\
function this.init_module()\
\9utils = require(\"Health_Bars.utils\");\
\9config = require(\"Health_Bars.config\");\
\9singletons = require(\"Health_Bars.singletons\");\
\9drawing = require(\"Health_Bars.drawing\");\
\9customization_menu = require(\"Health_Bars.customization_menu\");\
end\
\
return this;", '@'..".\\Health_Bars\\enemy_handler.lua" ) )

package.preload[ "Health_Bars.screen" ] = assert( (loadstring or load)( "local this = {};\
\
local config;\
local singletons;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
this.width = 1920;\
this.height = 1080;\
\
function this.update_window_size()\
\9local width;\
\9local height;\
\
\9if d2d ~= nil and config.current_config.settings.use_d2d_if_available then\
\9\9width, height = d2d.surface_size();\
\9else\
\9\9width, height = this.get_game_window_size();\
\9end\
\
\9if width ~= nil then\
\9\9this.width = width;\
\9end\
\
\9if height ~= nil then\
\9\9this.height = height;\
\9end\
end\
\
local scene_view;\
local scene_view_type = sdk.find_type_definition(\"via.SceneView\");\
local get_size_method = scene_view_type:get_method(\"get_Size\");\
\
local size_type = get_size_method:get_return_type();\
local width_field = size_type:get_field(\"w\");\
local height_field = size_type:get_field(\"h\");\
\
function this.get_game_window_size()\
\9if scene_view == nil then\
\9\9if singletons.scene_manager == nil then\
\9\9\9return;\
\9\9end\
\
\9\9scene_view = sdk.call_native_func(singletons.scene_manager, sdk.find_type_definition(\"via.SceneManager\"), \"get_MainView\");\
\
\9\9if scene_view == nil then\
\9\9\9return;\
\9\9end\
\9end\
\
\9local size = get_size_method:call(scene_view);\
\9if size == nil then\
\9\9return;\
\9end\
\
\9local screen_width = width_field:get_data(size);\
\9if screen_width == nil then\
\9\9return;\
\9end\
\
\9local screen_height = height_field:get_data(size);\
\9if screen_height == nil then\
\9\9return;\
\9end\
\
\9return screen_width, screen_height;\
end\
\
function this.init_module()\
\9config = require(\"Health_Bars.config\");\
\9singletons = require(\"Health_Bars.singletons\");\
end\
\
return this;\
", '@'..".\\Health_Bars\\screen.lua" ) )

package.preload[ "Health_Bars.singletons" ] = assert( (loadstring or load)( "local singletons = {};\
\
local customization_menu;\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
local character_manager_name = \"chainsaw.CharacterManager\";\
local scene_manager_name = \"via.SceneManager\";\
\
singletons.character_manager = nil;\
singletons.scene_manager = nil;\
\
function singletons.init()\
\9singletons.init_character_manager();\
\9singletons.init_scene_manager();\
end\
\
function singletons.init_character_manager()\
\9if singletons.character_manager ~= nil then\
\9\9return;\
\9end\
\
\9singletons.character_manager = sdk.get_managed_singleton(character_manager_name);\
\9if singletons.character_manager == nil then\
\9\9customization_menu.status = \"No Character Manager\";\
\9end\
\
\9return singletons.character_manager;\
end\
\
function singletons.init_scene_manager()\
\9if singletons.scene_manager ~= nil then\
\9\9return;\
\9end\
\
\9singletons.scene_manager = sdk.get_native_singleton(scene_manager_name);\
\9if singletons.scene_manager == nil then\
\9\9customization_menu.status = \"No Scene Manager\";\
\9end\
\
\9return singletons.scene_manager;\
end\
\
function singletons.init_module()\
\9customization_menu = require(\"Health_Bars.customization_menu\");\
\
\9singletons.init();\
end\
\
return singletons;\
", '@'..".\\Health_Bars\\singletons.lua" ) )

package.preload[ "Health_Bars.utils" ] = assert( (loadstring or load)( "local this = {};\
\
local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
local table_tostring;\
local deep_copy;\
local merge;\
local is_empty;\
\
function this.table_tostring(table_)\
\9if type(table_) == \"number\" or type(table_) == \"boolean\" or type(table_) == \"string\" then\
\9\9return tostring(table_);\
\9end\
\
\9if is_empty(table_) then\
\9\9return \"{}\"; \
\9end\
\
\9local cache = {};\
\9local stack = {};\
\9local output = {};\
    local depth = 1;\
    local output_str = \"{\\n\";\
\
    while true do\
        local size = 0;\
        for k,v in pairs(table_) do\
            size = size + 1;\
        end\
\
        local cur_index = 1;\
        for k,v in pairs(table_) do\
            if cache[table_] == nil or cur_index >= cache[table_] then\
\
                if string.find(output_str, \"}\", output_str:len()) then\
                    output_str = output_str .. \",\\n\";\
                elseif not string.find(output_str, \"\\n\", output_str:len()) then\
                    output_str = output_str .. \"\\n\";\
                end\
\
                -- This is necessary for working with HUGE tables otherwise we run out of memory using concat on huge strings\
                table.insert(output,output_str);\
                output_str = \"\";\
\
                local key;\
                if type(k) == \"number\" or type(k) == \"boolean\" then\
                    key = \"[\" .. tostring(k) .. \"]\";\
                else\
                    key = \"['\" .. tostring(k) .. \"']\";\
                end\
\
                if type(v) == \"number\" or type(v) == \"boolean\" then\
                    output_str = output_str .. string.rep('\\t', depth) .. key .. \" = \"..tostring(v);\
                elseif type(v) == \"table\" then\
                    output_str = output_str .. string.rep('\\t', depth) .. key .. \" = {\\n\";\
                    table.insert(stack, table_);\
                    table.insert(stack, v);\
                    cache[table_] = cur_index + 1;\
                    break;\
                else\
                    output_str = output_str .. string.rep('\\t', depth) .. key .. \" = '\" .. tostring(v) .. \"'\";\
                end\
\
                if cur_index == size then\
                    output_str = output_str .. \"\\n\" .. string.rep('\\t', depth - 1) .. \"}\";\
                else\
                    output_str = output_str .. \",\";\
                end\
            else\
                -- close the table\
                if cur_index == size then\
                    output_str = output_str .. \"\\n\" .. string.rep('\\t', depth - 1) .. \"}\";\
                end\
            end\
\
            cur_index = cur_index + 1;\
        end\
\
        if size == 0 then\
            output_str = output_str .. \"\\n\" .. string.rep('\\t', depth - 1) .. \"}\";\
        end\
\
        if #stack > 0 then\
            table_ = stack[#stack];\
            stack[#stack] = nil;\
            depth = cache[table_] == nil and depth + 1 or depth - 1;\
        else\
            break;\
        end\
    end\
\
    -- This is necessary for working with HUGE tables otherwise we run out of memory using concat on huge strings\
    table.insert(output, output_str);\
    output_str = table.concat(output);\
\
    return output_str;\
end\
\
function this.table_tostringln(table_)\
\9return \"\\n\" .. table_tostring(table_);\
end\
\
function this.table_is_empty(table_)\
\9return next(table_) == nil;\
end\
\
function this.table_deep_copy(original, copies)\
\9copies = copies or {};\
\9local original_type = type(original);\
\9local copy;\
\9if original_type == \"table\" then\
\9\9if copies[original] then\
\9\9\9copy = copies[original];\
\9\9else\
\9\9\9copy = {};\
\9\9\9copies[original] = copy;\
\9\9\9for original_key, original_value in next, original, nil do\
\9\9\9\9copy[deep_copy(original_key, copies)] = deep_copy(original_value,copies);\
\9\9\9end\
\9\9\9setmetatable(copy, deep_copy(getmetatable(original), copies));\
\9\9end\
\9else -- number, string, boolean, etc\
\9\9copy = original;\
\9end\
\9return copy;\
end\
\
function this.table_find_index(table_, value, nullable)\
\9for i = 1, #table_ do\
\9\9if table_[i] == value then\
\9\9\9return i;\
\9\9end\
\9end\
\
\9if not nullable then\
\9\9return 1;\
\9end\
\
\9return nil;\
end\
\
function this.table_merge(...)\
\9local tables_to_merge = { ... };\
\9assert(#tables_to_merge > 1, \"There should be at least two tables to merge them\");\
\
\9for key, table_ in ipairs(tables_to_merge) do\
\9\9assert(type(table_) == \"table\", string.format(\"Expected a table as function parameter %d\", key));\
\9end\
\
\9local result = deep_copy(tables_to_merge[1]);\
\
\9for i = 2, #tables_to_merge do\
\9\9local from = tables_to_merge[i];\
\9\9for key, value in pairs(from) do\
\9\9\9if type(value) == \"table\" then\
\9\9\9\9result[key] = result[key] or {};\
\9\9\9\9assert(type(result[key]) == \"table\", string.format(\"Expected a table: '%s'\", key));\
\9\9\9\9result[key] = merge(result[key], value);\
\9\9\9else\
\9\9\9\9result[key] = value;\
\9\9\9end\
\9\9end\
\9end\
\
\9return result;\
end\
\
function this.number_is_NaN(value)\
\9return tostring(value) == tostring(0/0);\
end\
\
function this.number_round(value)\
\9return math.floor(value + 0.5);\
end\
\
function this.string_trim(str)\
\9return str:match(\"^%s*(.-)%s*$\");\
end\
\
function this.string_starts_with(str, pattern)\
\9return str:find(\"^\" .. pattern) ~= nil;\
end\
\
function this.init_module()\
end\
\
table_tostring = this.table_tostring;\
deep_copy = this.table_deep_copy;\
merge = this.table_merge;\
is_empty = this.table_is_empty;\
\
return this;", '@'..".\\Health_Bars\\utils.lua" ) )

assert( (loadstring or load)( "local sdk = sdk;\
local tostring = tostring;\
local pairs = pairs;\
local ipairs = ipairs;\
local tonumber = tonumber;\
local require = require;\
local pcall = pcall;\
local table = table;\
local string = string;\
local Vector3f = Vector3f;\
local d2d = d2d;\
local math = math;\
local json = json;\
local log = log;\
local fs = fs;\
local next = next;\
local type = type;\
local setmetatable = setmetatable;\
local getmetatable = getmetatable;\
local assert = assert;\
local select = select;\
local coroutine = coroutine;\
local utf8 = utf8;\
local re = re;\
local imgui = imgui;\
local draw = draw;\
local Vector2f = Vector2f;\
local reframework = reframework;\
\
local drawing = require(\"Health_Bars.drawing\");\
local utils = require(\"Health_Bars.utils\");\
local config = require(\"Health_Bars.config\");\
local screen = require(\"Health_Bars.screen\");\
local singletons = require(\"Health_Bars.singletons\");\
\
local bar_customization = require(\"Health_Bars.bar_customization\");\
local customization_menu = require(\"Health_Bars.customization_menu\");\
\
local enemy_handler = require(\"Health_Bars.enemy_handler\");\
\
------------------------INIT MODULES-------------------------\
-- #region\
drawing.init_module();\
utils.init_module();\
config.init_module();\
screen.init_module();\
singletons.init_module();\
\
bar_customization.init_module();\
customization_menu.init_module();\
\
enemy_handler.init_module();\
\
log.info(\"[Health Bars] Loaded.\");\
-- #endregion\
------------------------INIT MODULES-------------------------\
\
----------------------------LOOP-----------------------------\
-- #region\
\
local function main_loop()\
\9local cached_config = config.current_config;\
\
\9if not cached_config.enabled then\
\9\9return;\
\9end\
\
\9customization_menu.status = \"OK\";\
\
\9singletons.init();\
\9screen.update_window_size();\
\9enemy_handler.update_player_position();\
\
\9enemy_handler.update_enemies();\
\9enemy_handler.draw_enemies();\
end\
\
-- #endregion\
----------------------------LOOP-----------------------------\
\
--------------------------RE_IMGUI---------------------------\
-- #region\
re.on_draw_ui(function()\
\9local changed = false;\
\9local cached_config = config.current_config;\
\
\9if imgui.button(\"Health Bars v\" .. config.current_config.version) then\
\9\9customization_menu.is_opened = not customization_menu.is_opened;\
\9end\
\
\9imgui.same_line();\
\
\9changed, cached_config.enabled = imgui.checkbox(\"Enabled\", cached_config.enabled);\
\9if changed then\
\9\9config.save();\
\9end\
end);\
\
re.on_frame(function()\
\9if not reframework:is_drawing_ui() then\
\9\9customization_menu.is_opened = false;\
\9end\
\
\9if customization_menu.is_opened then\
\9\9pcall(customization_menu.draw);\
\9end\
end);\
-- #endregion\
--------------------------RE_IMGUI---------------------------\
\
----------------------------D2D------------------------------\
-- #region\
if d2d ~= nil then\
\9d2d.register(function()\
\9\9drawing.init_font();\
\9end, function() \
\9\9if config.current_config.settings.use_d2d_if_available then\
\9\9\9main_loop();\
\9\9end\
\9end);\
end\
\
re.on_frame(function()\
\9if d2d == nil or not config.current_config.settings.use_d2d_if_available then\
\9\9main_loop();\
\9end\
end);\
-- #endregion\
----------------------------D2D------------------------------", '@'.."E:\\GitHub\\RE4-Health-Bars\\reframework\\autorun\\Health_Bars.lua" ) )( ... )

